package com.iverson.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("emp1")
public class Employee {
	private int empId;
	private String empName;
	private int empSal;
	private String designation;
	 @Autowired
	private Address address;// has-a

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Address getAddress() {
		return address;
	}

	//@Autowired
	public void setAddress(Address address) {
		this.address = address;
	}

	//@Autowired
	public Employee(int empId, String empName, int empSal, String designation, Address address) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.designation = designation;
		this.address = address;
	}

//	@Override
//	public String toString() {
//		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", designation="
//				+ designation + ", address=" + address + "]";
//	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

}
