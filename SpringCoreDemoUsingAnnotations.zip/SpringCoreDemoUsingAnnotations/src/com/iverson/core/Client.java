package com.iverson.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.iverson.core")
public class Client {
	public static void main(String[] args) {

		ApplicationContext factory = new AnnotationConfigApplicationContext(Client.class); // eager intializer
		Employee employee1 = (Employee) factory.getBean("emp1");
		System.out.println(employee1);
		System.out.println(employee1.getAddress());

	}
}
//@Component,@ComponentScan,@Autowired,@Configuration