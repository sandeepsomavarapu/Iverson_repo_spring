package com.iverson.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	public static void main(String[] args) {
//container-->BeanFactory,ApplicationContext
		// Employee emp=new Employee();
		// Resource resource = new ClassPathResource("springconfig.xml");// lazy
		// Intializer
//		BeanFactory factory = new XmlBeanFactory(resource);//will not create objects at the time loading
//small scale 

		ApplicationContext factory = new ClassPathXmlApplicationContext("springconfig.xml"); // eager intializer
		//System.out.println("ApplicationContext is Eager Intializer ....");
		 Employee employee1 = (Employee) factory.getBean("emp1");

		System.out.println(employee1);
		
		 Employee employee2 = (Employee) factory.getBean("emp2");

			System.out.println(employee2);

	}
}
