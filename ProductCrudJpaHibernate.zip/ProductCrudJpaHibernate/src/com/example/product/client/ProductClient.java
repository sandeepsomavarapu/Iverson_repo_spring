package com.example.product.client;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.example.product.model.Product;

public class ProductClient {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("demo");
		EntityManager entityManager = factory.createEntityManager();// persist(),merge(),remove(),find(),createQuery
		int productid;
		String productname;
		int productprice;
		int quantity;
		String description;
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("***************ProductManagemet Application************");
			System.out.println("1.Add Product");
			System.out.println("2.Update Product");
			System.out.println("3.Delete Product");
			System.out.println("4.Get Product");
			System.out.println("5.GetAll Product");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Add Product");
				System.out.println("Enter Product Name");
				productname = scan.next();
				System.out.println("Enter Product Price");
				productprice = scan.nextInt();
				System.out.println("Enter Product Quantity");
				quantity = scan.nextInt();
				System.out.println("Enter Product Description");
				description = scan.next();
				Product product = new Product(productname, productprice, quantity, description);
				entityManager.getTransaction().begin();
				entityManager.persist(product);
				entityManager.getTransaction().commit();
				System.out.println("Product Insrted Successfully :" + product.getProductid());
				break;
			case 2:
				System.out.println("Update Product");

				System.out.println("Enter Product Id");
				productid = scan.nextInt();
				System.out.println("Enter Product Name");
				productname = scan.next();
				System.out.println("Enter Product Price");
				productprice = scan.nextInt();
				System.out.println("Enter Product Quantity");
				quantity = scan.nextInt();
				System.out.println("Enter Product Description");
				description = scan.next();
				Product product1 = new Product(productid,productname, productprice, quantity, description);
				entityManager.getTransaction().begin();
				entityManager.merge(product1);
				entityManager.getTransaction().commit();
				System.out.println("Product Updated Successfully " + product1.getProductid());
				break;
			case 3:
				System.out.println("Delete Product");

				System.out.println("Enter Product Id");
				productid = scan.nextInt();
				Product product2 = entityManager.find(Product.class, productid);
				entityManager.getTransaction().begin();
				entityManager.remove(product2);
				entityManager.getTransaction().commit();
				
				break;
			case 4:

				System.out.println("Enter Product Id");
				productid = scan.nextInt();
				Product product3 = entityManager.find(Product.class, productid);
				System.out.println(product3);
				break;
			case 5:
				TypedQuery<Product> product4 = entityManager.createQuery("select p from Product p", Product.class);
				System.out.println(product4.getResultList());
				break;
			default:
				System.exit(0);
			}
		}
	}
}
