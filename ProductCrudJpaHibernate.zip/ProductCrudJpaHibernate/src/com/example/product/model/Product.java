package com.example.product.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="products_info")
public class Product {//ORM-->  class ,variables-->table,cloumns select p from products_info p
	@Id
	@GeneratedValue
	@Column(name="pid",length = 15)
	private int productid;
	@Column(name="pname",length = 15)
	private String productname;
	private int productprice;
	private int qunatity;
	private String description;

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	public int getQunatity() {
		return qunatity;
	}

	public void setQunatity(int qunatity) {
		this.qunatity = qunatity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Product(int productid, String productname, int productprice, int qunatity, String description) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
		this.qunatity = qunatity;
		this.description = description;
	}

	public Product(String productname, int productprice, int qunatity, String description) {
		super();
		this.productname = productname;
		this.productprice = productprice;
		this.qunatity = qunatity;
		this.description = description;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productname=" + productname + ", productprice=" + productprice
				+ ", qunatity=" + qunatity + ", description=" + description + "]";
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}
}
