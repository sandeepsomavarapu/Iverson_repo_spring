package com.jdbc.spring;

import java.sql.PreparedStatement;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

public class UserDAO {
	private JdbcTemplate jdbcTemplate; //template 
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	public Long save(User user) {
	    String insertSql = "INSERT INTO `USER` (USERNAME, PASSWORD, CREATEDTIME, UPDATEDTIME, USERTYPE, DATEOFBIRTH)"
	        + " VALUES(?,?,?,?,?,?)";

	    KeyHolder keyHolder = new GeneratedKeyHolder();

	    jdbcTemplate.update(connection -> {

	      PreparedStatement ps = connection.prepareStatement(insertSql, new String[] { "ID" });
	      ps.setString(1, user.getUserName());
	      ps.setString(2, user.getPassword());
	      ps.setDate(3, new java.sql.Date(user.getCreatedTime().getTime()));
	      ps.setDate(4, user.getUpdatedTime() == null ? null : new java.sql.Date(user.getUpdatedTime().getTime()));
	      ps.setString(5, user.getUserType().toString());
	      ps.setDate(6, new java.sql.Date(user.getDateofBirth().getTime()));

	      return ps;

	    }, keyHolder);

	    return keyHolder.getKey().longValue();
	  }
}
//CREATE TABLE `USER` (
//	    `ID` bigint(11) NOT NULL AUTO_INCREMENT,
//	    `USERNAME` varchar(45) NOT NULL,
//	    `PASSWORD` varchar(45) NOT NULL,
//	    `CREATEDTIME` datetime NOT NULL,
//	    `UPDATEDTIME` datetime DEFAULT NULL,
//	    `USERTYPE` varchar(45) NOT NULL,
//	    `DATEOFBIRTH` date NOT NULL,
//	    PRIMARY KEY (`ID`),
//	    UNIQUE KEY `USER_NAME_UNIQUE` (`USERNAME`)
//	  );