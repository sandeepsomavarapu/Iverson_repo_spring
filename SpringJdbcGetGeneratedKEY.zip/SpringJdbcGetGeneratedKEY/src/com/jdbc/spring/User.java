package com.jdbc.spring;

import java.util.Date;

public class User {
	private Long id;
	private String userName;
	private String password;
	private Date createdTime;
	private Date updatedTime;
	private Date dateofBirth;
	private UserType userType; // Enum Type

	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(Long id, String userName, String password, Date createdTime, Date updatedTime, Date dateofBirth,
			UserType userType) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
		this.createdTime = createdTime;
		this.updatedTime = updatedTime;
		this.dateofBirth = dateofBirth;
		this.userType = userType;
	}

	

	public User(String userName, String password, Date createdTime, Date updatedTime, Date dateofBirth,
			UserType userType) {
		super();
		this.userName = userName;
		this.password = password;
		this.createdTime = createdTime;
		this.updatedTime = updatedTime;
		this.dateofBirth = dateofBirth;
		this.userType = userType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Date getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

}
