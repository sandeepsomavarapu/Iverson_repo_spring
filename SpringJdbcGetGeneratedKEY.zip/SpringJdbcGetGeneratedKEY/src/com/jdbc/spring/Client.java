package com.jdbc.spring;

import java.util.Date;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	public static void main(String[] args) {

		// Get the Spring Context
		Resource r = new ClassPathResource("applicationConfig.xml");
		BeanFactory ctx = new XmlBeanFactory(r);
		UserDAO dao = (UserDAO) ctx.getBean("userDao");
		
		User user = new User("hitesh", "sandeep123", new Date(), new Date(), new Date(), UserType.EMPLOYEE);
		System.out.println("User Created with ID :" + dao.save(user));
		
		User user1 = new User("somesh", "mahesh123", new Date(), new Date(), new Date(), UserType.STUDENT);
		System.out.println("User Created with ID :" + dao.save(user1));

	}

}
