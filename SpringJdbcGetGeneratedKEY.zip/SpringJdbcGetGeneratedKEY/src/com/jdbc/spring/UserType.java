package com.jdbc.spring;

public enum UserType {

	EMPLOYEE, STUDENT;
}
