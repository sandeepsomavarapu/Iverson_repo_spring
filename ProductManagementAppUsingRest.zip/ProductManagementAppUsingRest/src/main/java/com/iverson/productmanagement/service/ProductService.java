package com.iverson.productmanagement.service;

import java.util.List;

import com.iverson.productmanagement.entity.Product;

public interface ProductService {
	public String saveProduct(Product product);

	public String updateProduct(Product product);

	public String deleteProduct(int productId);

	public Product getProduct(int productId);

	public List<Product> getAllProduct();
}
