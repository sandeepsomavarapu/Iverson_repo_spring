package com.iverson.productmanagement.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.iverson.productmanagement.entity.Product;
import com.iverson.productmanagement.exception.ProductNotFoundException;

@Repository
public class ProductRepoImpl implements ProductRepo {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String saveProduct(Product product) {
		entityManager.persist(product);
		return "Product Saved Succesfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		Product p = getProduct(productId);
		if (p != null) {
			entityManager.remove(p);
		} else {
			throw new ProductNotFoundException("Invalid Product !!!!");
		}
		return "Product Delete Successfully";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProduct() {
		Query result = entityManager.createQuery("select p from Product p");

		return result.getResultList();
	}

}
